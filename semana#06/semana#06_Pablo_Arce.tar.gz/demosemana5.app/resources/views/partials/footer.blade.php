<footer>
  <span>Page created by <strong><a href="https://github.com/Pablo251">Pablo Arce</a></strong>.</span>
</footer>
