<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    @include('partials.header')
    <section>
      <p>
        A british rock band!
      </p>
      <p>
        Also, is the title of third album by them.
      </p>
    </section>
    @include('partials.footer')
  </body>
</html>
