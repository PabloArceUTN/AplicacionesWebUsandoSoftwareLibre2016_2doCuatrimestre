<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section>
      <p>
        A british rock band!
      </p>
      <p>
        Also, is the title of third album by them.
      </p>
      <ul>
        <li>caca</li>
      </ul>
    </section>
    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
